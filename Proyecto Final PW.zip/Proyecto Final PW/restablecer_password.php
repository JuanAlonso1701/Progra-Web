<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Restablecer Contraseña - Avanza</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Encabezado -->
    <header class="encabezado">
        <div class="contenedor">
            <h1 class="logo">Avanza</h1>
            <nav class="navegacion">
                <a href="index.html" class="boton-secundario">Inicio</a>
                <a href="ingresar.php" class="boton-principal">Ingresar</a>
            </nav>
        </div>
    </header>

    <!-- Formulario de Restablecimiento -->
    <section class="formulario-seccion">
        <div class="contenedor">
            <h2 class="titulo">Restablecer Contraseña</h2>
            <form action="procesar_restablecer.php" method="POST" class="formulario">
                <div class="campo-formulario">
                    <label for="email">Correo electrónico:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <p class="texto-ayuda">
                    Te enviaremos un enlace a tu correo electrónico para restablecer tu contraseña.
                </p>

                <button type="submit" class="boton-principal">Enviar enlace</button>
            </form>
        </div>
    </section>

    <!-- Pie de página -->
    <footer class="pie">
        <div class="contenedor">
            <p>Contacto: <a href="mailto:contactoavanza@gmail.com">contactoavanza@gmail.com</a></p>
            <p>© 2025 Avanza. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html> 