<?php
session_start();

// Incluir archivo de conexión a la base de datos
require_once 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Por favor, complete todos los campos";
        header("Location: ingresar.php");
        exit();
    }

    try {
        // Consulta para verificar el usuario
        $stmt = $conn->prepare("SELECT id, nombre, email, password, es_admin FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();

        if ($usuario && password_verify($password, $usuario['password'])) {
            // Login exitoso
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'];
            $_SESSION['usuario_email'] = $usuario['email'];
            $_SESSION['es_admin'] = $usuario['es_admin'];
            
            header("Location: home/index.php");
            exit();
        } else {
            $_SESSION['error'] = "Credenciales inválidas";
            header("Location: ingresar.php");
            exit();
        }
    } catch(PDOException $e) {
        $_SESSION['error'] = "Error al procesar el login: " . $e->getMessage();
        header("Location: ingresar.php");
        exit();
    }
} else {
    header("Location: ingresar.php");
    exit();
}
?> 