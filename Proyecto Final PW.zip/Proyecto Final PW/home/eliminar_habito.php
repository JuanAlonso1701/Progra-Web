<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No autorizado']);
    exit();
}

require_once '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT);
    try {
        // Verificar que el hábito pertenece al usuario
        $stmt = $conn->prepare("SELECT id FROM habitos WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$id, $_SESSION['usuario_id']]);
        if ($stmt->rowCount() === 0) {
            echo json_encode(['error' => 'No autorizado o hábito no encontrado']);
            exit();
        }
        // Eliminar el hábito (y sus seguimientos por ON DELETE CASCADE)
        $stmt = $conn->prepare("DELETE FROM habitos WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);
    } catch(PDOException $e) {
        echo json_encode(['error' => 'Error al eliminar el hábito: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Solicitud inválida']);
}
?> 