<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No autorizado']);
    exit();
}

// Incluir archivo de conexión
require_once '../conexion.php';

try {
    // Obtener datos de la última semana
    $stmt = $conn->prepare("
        SELECT 
            DAYOFWEEK(fecha) as dia,
            COUNT(CASE WHEN completado = 1 THEN 1 END) as completados
        FROM seguimiento_habitos sh
        JOIN habitos h ON sh.habito_id = h.id
        WHERE h.usuario_id = ?
        AND fecha >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY fecha
        ORDER BY fecha
    ");
    
    $stmt->execute([$_SESSION['usuario_id']]);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Preparar datos para el gráfico
    $datos = array_fill(0, 7, 0); // Inicializar array con 7 ceros
    
    foreach ($resultados as $row) {
        // Ajustar índice para que 1 (Domingo) sea el último día
        $indice = ($row['dia'] + 5) % 7;
        $datos[$indice] = (int)$row['completados'];
    }
    
    header('Content-Type: application/json');
    echo json_encode($datos);
} catch(PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
}
?> 