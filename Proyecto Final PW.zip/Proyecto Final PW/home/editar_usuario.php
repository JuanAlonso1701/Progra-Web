<?php
session_start();

// Verificar si el usuario está logueado y es administrador
if (!isset($_SESSION['usuario_id']) || !$_SESSION['es_admin']) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No autorizado']);
    exit();
}

// Incluir archivo de conexión
require_once '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT);
    $nombre = filter_var($_POST['nombre'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $es_admin = isset($_POST['es_admin']) ? 1 : 0;

    try {
        $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, email = ?, es_admin = ? WHERE id = ?");
        $stmt->execute([$nombre, $email, $es_admin, $id]);
        
        echo json_encode(['success' => true]);
    } catch(PDOException $e) {
        echo json_encode(['error' => 'Error al actualizar usuario: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Método no permitido']);
}
?> 