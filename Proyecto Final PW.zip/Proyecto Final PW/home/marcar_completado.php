<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../ingresar.php");
    exit();
}

// Incluir archivo de conexión
require_once '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['habito_id'])) {
    $habito_id = filter_var($_POST['habito_id'], FILTER_SANITIZE_NUMBER_INT);
    $fecha = date('Y-m-d');

    // Obtener tipo de frecuencia del hábito
    $stmt = $conn->prepare("SELECT frecuencia FROM habitos WHERE id = ?");
    $stmt->execute([$habito_id]);
    $habito = $stmt->fetch();
    $frecuencia = $habito ? $habito['frecuencia'] : 'diario';

    try {
        if ($frecuencia === 'semanal') {
            // Para semanal, buscar si ya hay un registro en la misma semana
            $stmt = $conn->prepare("
                SELECT id FROM seguimiento_habitos 
                WHERE habito_id = ? AND YEARWEEK(fecha, 1) = YEARWEEK(?, 1)
            ");
            $stmt->execute([$habito_id, $fecha]);
        } else {
            // Para diario, buscar por fecha exacta
            $stmt = $conn->prepare("SELECT id FROM seguimiento_habitos WHERE habito_id = ? AND fecha = ?");
            $stmt->execute([$habito_id, $fecha]);
        }

        if ($stmt->rowCount() > 0) {
            // Actualizar registro existente (toggle)
            if ($frecuencia === 'semanal') {
                $row = $stmt->fetch();
                $stmt2 = $conn->prepare("UPDATE seguimiento_habitos SET completado = NOT completado WHERE id = ?");
                $stmt2->execute([$row['id']]);
            } else {
                $stmt2 = $conn->prepare("UPDATE seguimiento_habitos SET completado = NOT completado WHERE habito_id = ? AND fecha = ?");
                $stmt2->execute([$habito_id, $fecha]);
            }
        } else {
            // Crear nuevo registro
            $stmt = $conn->prepare("INSERT INTO seguimiento_habitos (habito_id, fecha, completado) VALUES (?, ?, TRUE)");
            $stmt->execute([$habito_id, $fecha]);
        }

        $_SESSION['mensaje'] = "Estado del hábito actualizado";
    } catch(PDOException $e) {
        $_SESSION['error'] = "Error al actualizar el hábito: " . $e->getMessage();
    }

    header("Location: index.php");
    exit();
} else {
    header("Location: index.php");
    exit();
}
?> 