<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../ingresar.php");
    exit();
}

// Incluir archivo de conexión
require_once '../conexion.php';

// Verificar si el usuario es administrador
try {
    $stmt = $conn->prepare("SELECT es_admin FROM usuarios WHERE id = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $usuario = $stmt->fetch();
    $es_admin = isset($usuario['es_admin']) && ($usuario['es_admin'] == 1);
} catch(PDOException $e) {
    $error = "Error al verificar permisos: " . $e->getMessage();
    $es_admin = false;
}

// Si es administrador, obtener lista de usuarios
if ($es_admin) {
    try {
        $stmt = $conn->prepare("SELECT id, nombre, email, fecha_registro FROM usuarios ORDER BY fecha_registro DESC");
        $stmt->execute();
        $usuarios = $stmt->fetchAll();
    } catch(PDOException $e) {
        $error = "Error al cargar usuarios: " . $e->getMessage();
    }
} else {
    // Si no es admin, obtener hábitos del usuario
    try {
        $stmt = $conn->prepare("SELECT * FROM habitos WHERE usuario_id = ? ORDER BY fecha_creacion DESC");
        $stmt->execute([$_SESSION['usuario_id']]);
        $habitos = $stmt->fetchAll();
    } catch(PDOException $e) {
        $error = "Error al cargar los hábitos: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $es_admin ? 'Panel de Administración' : 'Panel de Hábitos'; ?> - Avanza</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php if ($es_admin): ?>
        <!-- Botón de cerrar sesión solo para admin -->
        <a href="../cerrar_sesion.php" class="boton-secundario" style="position: fixed; top: 20px; left: 20px; z-index: 1100; background:#e74c3c; color:#fff; text-align:center; border-radius:5px; padding: 10px 18px; font-size: 1.1em; text-decoration: none;">Cerrar Sesión</a>
    <?php else: ?>
        <!-- Botón hamburguesa y menú lateral para usuarios normales -->
        <button class="btn-menu" id="btnMenu" title="Abrir menú">&#9776;</button>
        <nav class="menu-lateral oculto" id="menuLateral">
            <ul>
                <li><a href="#" id="btn-agregar" class="activo" onclick="mostrarSeccion('agregar')">Agregar hábitos</a></li>
                <li><a href="#" id="btn-editar" onclick="mostrarSeccion('editar')">Editar hábitos</a></li>
                <li><a href="#" id="btn-progreso" onclick="mostrarSeccion('progreso')">Ver progreso</a></li>
                <li><a href="#" id="btn-insignias" onclick="mostrarSeccion('insignias')">Insignias</a></li>
            </ul>
            <div style="margin-top:40px; padding:0 30px;">
                <a href="../cerrar_sesion.php" class="boton-secundario" style="display:block; background:#e74c3c; color:#fff; text-align:center; border-radius:5px; margin-top:20px;">Cerrar Sesión</a>
            </div>
        </nav>
    <?php endif; ?>
    <!-- Encabezado -->
    <header class="encabezado">
        <div class="contenedor">
            <h1 class="logo">Avanza</h1>
            <nav class="navegacion">
                <span class="usuario">Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario_nombre']); ?></span>
            </nav>
        </div>
    </header>

    <!-- Contenido Principal -->
    <main class="contenido-principal expandido" id="contenidoPrincipal">
        <div class="contenedor">
            <h2 class="titulo"><?php echo $es_admin ? 'Panel de Administración' : 'Panel de Control de Hábitos'; ?></h2>
            
            <?php if ($es_admin): ?>
                <!-- Lista de usuarios para administrador -->
                <?php if (isset($error)): ?>
                    <div class="error"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <table class="tabla-usuarios">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Fecha de Registro</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $usuario): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($usuario['id']); ?></td>
                                <td><?php echo htmlspecialchars($usuario['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                                <td><?php echo date('d/m/Y H:i', strtotime($usuario['fecha_registro'])); ?></td>
                                <td>
                                    <button class="boton-accion boton-editar" onclick="editarUsuario(<?php echo $usuario['id']; ?>)">Editar</button>
                                    <button class="boton-accion boton-eliminar" onclick="eliminarUsuario(<?php echo $usuario['id']; ?>)">Eliminar</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <!-- Sección para agregar nuevo hábito -->
                <section class="nuevo-habito" id="seccion-agregar">
                    <div class="tarjeta-habito">
                        <span class="icono-habito">📝</span>
                        <h3><span>Agregar Nuevo Hábito</span></h3>
                        <form action="procesar_habito.php" method="POST" class="formulario">
                            <div class="campo">
                                <label for="nombre">Nombre del Hábito:</label>
                                <input type="text" id="nombre" name="nombre" required placeholder="Ej: Leer 10 páginas">
                            </div>
                            <div class="campo">
                                <label for="descripcion">Descripción:</label>
                                <textarea id="descripcion" name="descripcion" placeholder="Describe tu hábito..."></textarea>
                            </div>
                            <div class="campo">
                                <label for="frecuencia">Frecuencia:</label>
                                <select id="frecuencia" name="frecuencia" required>
                                    <option value="diario">Diario</option>
                                    <option value="semanal">Semanal</option>
                                </select>
                            </div>
                            <div class="campo" id="dias-semana" style="display: none;">
                                <label>Días de la semana:</label>
                                <div class="checkbox-grupo">
                                    <label><input type="checkbox" name="dias[]" value="1"> Lunes</label>
                                    <label><input type="checkbox" name="dias[]" value="2"> Martes</label>
                                    <label><input type="checkbox" name="dias[]" value="3"> Miércoles</label>
                                    <label><input type="checkbox" name="dias[]" value="4"> Jueves</label>
                                    <label><input type="checkbox" name="dias[]" value="5"> Viernes</label>
                                    <label><input type="checkbox" name="dias[]" value="6"> Sábado</label>
                                    <label><input type="checkbox" name="dias[]" value="0"> Domingo</label>
                                </div>
                            </div>
                            <button type="submit" class="boton-primario">Agregar Hábito</button>
                        </form>
                    </div>
                </section>
                <section class="lista-habitos-separada">
                    <h3>Mis Hábitos</h3>
                    <?php if (isset($error)): ?>
                        <div class="error"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <div class="habitos-grid">
                        <?php foreach ($habitos as $habito): ?>
                            <div class="habito-card">
                                <h4><?php echo htmlspecialchars($habito['nombre']); ?></h4>
                                <p><?php echo htmlspecialchars($habito['descripcion']); ?></p>
                                <p>Frecuencia: <?php echo ucfirst($habito['frecuencia']); ?></p>
                                <?php if ($habito['frecuencia'] == 'semanal'): ?>
                                    <p>Días: <?php echo htmlspecialchars($habito['dias_semana']); ?></p>
                                <?php endif; ?>
                                <form action="marcar_completado.php" method="POST" class="form-completado">
                                    <input type="hidden" name="habito_id" value="<?php echo $habito['id']; ?>">
                                    <button type="submit" class="boton-completado">Marcar como Completado</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- Sección para editar hábitos -->
                <section class="editar-habito" id="seccion-editar" style="display:none">
                    <h3>Editar o Eliminar Hábitos</h3>
                    <div class="habitos-grid" id="habitosEditarGrid">
                        <?php foreach ($habitos as $habito): ?>
                            <div class="habito-card" data-id="<?php echo $habito['id']; ?>" data-nombre="<?php echo htmlspecialchars($habito['nombre']); ?>" data-descripcion="<?php echo htmlspecialchars($habito['descripcion']); ?>" data-frecuencia="<?php echo $habito['frecuencia']; ?>" data-dias="<?php echo $habito['dias_semana']; ?>">
                                <h4><?php echo htmlspecialchars($habito['nombre']); ?></h4>
                                <p><?php echo htmlspecialchars($habito['descripcion']); ?></p>
                                <p>Frecuencia: <?php echo ucfirst($habito['frecuencia']); ?></p>
                                <?php if ($habito['frecuencia'] == 'semanal'): ?>
                                    <p>Días: <?php echo htmlspecialchars($habito['dias_semana']); ?></p>
                                <?php endif; ?>
                                <div>
                                    <button type="button" class="boton-primario btn-editar-habito">Editar</button>
                                    <button type="button" class="boton-secundario btn-eliminar-habito">Eliminar</button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <!-- Modal editar hábito -->
                    <div id="modalEditarHabito">
                        <div class="modal-contenido">
                            <button class="cerrar-modal" onclick="cerrarModalEditar()">&times;</button>
                            <h3>Editar Hábito</h3>
                            <form id="formEditarHabito" class="formulario">
                                <input type="hidden" name="id" id="editar_id">
                                <div class="campo">
                                    <label for="editar_nombre">Nombre del Hábito:</label>
                                    <input type="text" id="editar_nombre" name="nombre" required>
                                </div>
                                <div class="campo">
                                    <label for="editar_descripcion">Descripción:</label>
                                    <textarea id="editar_descripcion" name="descripcion"></textarea>
                                </div>
                                <div class="campo">
                                    <label for="editar_frecuencia">Frecuencia:</label>
                                    <select id="editar_frecuencia" name="frecuencia" required>
                                        <option value="diario">Diario</option>
                                        <option value="semanal">Semanal</option>
                                    </select>
                                </div>
                                <div class="campo" id="editar_dias-semana" style="display: none;">
                                    <label>Días de la semana:</label>
                                    <div class="checkbox-grupo">
                                        <label><input type="checkbox" name="dias[]" value="1"> Lunes</label>
                                        <label><input type="checkbox" name="dias[]" value="2"> Martes</label>
                                        <label><input type="checkbox" name="dias[]" value="3"> Miércoles</label>
                                        <label><input type="checkbox" name="dias[]" value="4"> Jueves</label>
                                        <label><input type="checkbox" name="dias[]" value="5"> Viernes</label>
                                        <label><input type="checkbox" name="dias[]" value="6"> Sábado</label>
                                        <label><input type="checkbox" name="dias[]" value="0"> Domingo</label>
                                    </div>
                                </div>
                                <button type="submit" class="boton-primario">Guardar Cambios</button>
                            </form>
                        </div>
                    </div>
                </section>

                <!-- Gráfico de progreso -->
                <section class="grafico-progreso" id="seccion-progreso" style="display:none">
                    <h3>Progreso de Hábitos</h3>
                    <canvas id="graficoHabitos"></canvas>
                    <h3 style="margin-top:32px;">Avance Semanal por Hábito</h3>
                    <canvas id="graficoAvanceSemanal"></canvas>
                    <h3 style="margin-top:32px;">Avance Total por Hábito</h3>
                    <canvas id="graficoAvanceTotal"></canvas>
                </section>

                <!-- Sección de insignias -->
                <section class="insignias" id="seccion-insignias" style="display:none; text-align:center;">
                    <h3 style="text-align:center;">Insignias por Hábitos Completados</h3>
                    <div class="insignias-grid" style="display:inline-block;">
                        <?php
                        $maxInsignias = 20;
                        $habitosCompletados = 0;
                        try {
                            // Contar la cantidad total de hábitos completados por el usuario
                            $stmt = $conn->prepare("
                                SELECT COUNT(*) as total
                                FROM seguimiento_habitos sh
                                JOIN habitos h ON sh.habito_id = h.id
                                WHERE h.usuario_id = ? AND sh.completado = 1
                            ");
                            $stmt->execute([$_SESSION['usuario_id']]);
                            $row = $stmt->fetch();
                            $habitosCompletados = $row ? (int)$row['total'] : 0;
                        } catch (Exception $e) {
                            echo '<div class="error">Error al cargar insignias: ' . $e->getMessage() . '</div>';
                        }
                        $insigniasGanadas = floor($habitosCompletados / 5);
                        for ($i = 0; $i < $maxInsignias; $i++) {
                            if ($i % 5 == 0) {
                                if ($i > 0) echo '</div>';
                                echo '<div class="fila-insignias" style="display:flex; gap:20px; margin-bottom:20px; justify-content:center;">';
                            }
                            echo '<div class="insignia-card">';
                            if ($i < $insigniasGanadas) {
                                $img = "insignias/insignia" . ($i+1) . ".png";
                                echo '<img src="' . $img . '" alt="Insignia ' . ($i+1) . '" style="width:48px;height:48px; cursor:pointer;" onclick="mostrarInsigniaModal(\'' . $img . '\', \'Insignia ' . ($i+1) . '\')">';
                                echo '<p>Insignia ' . ($i+1) . '</p>';
                            } else {
                                echo '<img src="insignias/insignia.jpg" alt="Por conseguir" style="width:48px;height:48px;filter:grayscale(1);opacity:0.5; cursor:pointer;" onclick="mostrarInsigniaModal(\'insignias/insignia.jpg\', \'Por conseguir\')">';
                                echo '<p>Por conseguir</p>';
                            }
                            echo '</div>';
                        }
                        echo '</div>'; // Cierra la última fila
                        ?>
                    </div>
                    <p style="text-align:center;">Lleva <?php echo $habitosCompletados; ?> hábitos completados. ¡Cada 5 completados desbloqueas una insignia!</p>
                </section>
            <?php endif; ?>
        </div>
    </main>

    <!-- Pie de página -->
    <footer class="pie">
        <div class="contenedor">
            <p>Contacto: <a href="mailto:contactoavanza@gmail.com">contactoavanza@gmail.com</a></p>
            <p>© 2025 Avanza. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- Modal para mostrar insignia en grande -->
    <div id="modalInsignia" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.7); justify-content:center; align-items:center; z-index:3000;">
        <div style="position:relative; background:#fff; border-radius:16px; padding:30px 30px 20px 30px; box-shadow:0 4px 24px rgba(0,0,0,0.18); max-width:90vw; max-height:90vh; display:flex; flex-direction:column; align-items:center;">
            <button id="cerrarModalInsignia" style="position:absolute; top:10px; right:18px; font-size:2em; background:none; border:none; color:#888; cursor:pointer;">&times;</button>
            <img id="imgModalInsignia" src="" alt="Insignia grande" style="max-width:300px; max-height:300px; margin-bottom:18px;">
            <p id="textoModalInsignia" style="font-size:1.2em; color:#222; margin:0;"></p>
        </div>
    </div>

    <script>
        // Mostrar/ocultar días de la semana según frecuencia
        const frecuenciaInput = document.getElementById('frecuencia');
        if (frecuenciaInput) {
            frecuenciaInput.addEventListener('change', function() {
                const diasSemana = document.getElementById('dias-semana');
                diasSemana.style.display = this.value === 'semanal' ? 'block' : 'none';
            });
        }

<?php if (!$es_admin): ?>
        // Menú desplegable SOLO para usuarios normales
        const btnMenu = document.getElementById('btnMenu');
        const menuLateral = document.getElementById('menuLateral');
        const contenidoPrincipal = document.getElementById('contenidoPrincipal');
        let menuVisible = false;

        function toggleMenu() {
            menuVisible = !menuVisible;
            if (menuVisible) {
                menuLateral.classList.remove('oculto');
                menuLateral.classList.add('mostrar');
                contenidoPrincipal.classList.remove('expandido');
            } else {
                menuLateral.classList.add('oculto');
                menuLateral.classList.remove('mostrar');
                contenidoPrincipal.classList.add('expandido');
            }
        }

        if (btnMenu) {
            btnMenu.addEventListener('click', function(e) {
                e.stopPropagation(); // Evita que el clic se propague y cierre el menú inmediatamente
                toggleMenu();
            });

            // Cerrar menú al hacer clic fuera de él en pantallas pequeñas
            document.addEventListener('click', function(e) {
                if (
                    window.innerWidth <= 1000 &&
                    menuVisible &&
                    !menuLateral.contains(e.target) &&
                    e.target !== btnMenu
                ) {
                    toggleMenu();
                }
            });

            // Evitar que los clics dentro del menú cierren el menú
            menuLateral.addEventListener('click', function(e) {
                e.stopPropagation();
            });
        }
<?php endif; ?>

        // Funciones para usuarios normales
        function mostrarSeccion(seccion) {
            document.getElementById('seccion-agregar').style.display = seccion === 'agregar' ? 'block' : 'none';
            document.getElementById('seccion-progreso').style.display = seccion === 'progreso' ? 'block' : 'none';
            document.getElementById('seccion-editar').style.display = seccion === 'editar' ? 'block' : 'none';
            document.getElementById('seccion-insignias').style.display = seccion === 'insignias' ? 'block' : 'none';
            document.getElementById('btn-agregar').classList.toggle('activo', seccion === 'agregar');
            document.getElementById('btn-progreso').classList.toggle('activo', seccion === 'progreso');
            document.getElementById('btn-editar').classList.toggle('activo', seccion === 'editar');
            document.getElementById('btn-insignias').classList.toggle('activo', seccion === 'insignias');
        }

        // Función para cargar datos del gráfico
        async function cargarDatosGrafico() {
            try {
                const response = await fetch('obtener_datos_grafico.php');
                const datos = await response.json();
                
                if (datos.error) {
                    console.error('Error:', datos.error);
                    return;
                }

                grafico.data.datasets[0].data = datos;
                grafico.update();
            } catch (error) {
                console.error('Error al cargar datos:', error);
            }
        }

        // Inicializar gráfico
        const ctx = document.getElementById('graficoHabitos').getContext('2d');
        const grafico = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'],
                datasets: [{
                    label: 'Hábitos Completados',
                    data: [0, 0, 0, 0, 0, 0, 0],
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                }
            }
        });

        // Cargar datos iniciales
        cargarDatosGrafico();
        // Actualizar datos cada 5 minutos
        setInterval(cargarDatosGrafico, 300000);

        // --- Editar y eliminar hábitos ---
        function abrirModalEditar(habito) {
            document.getElementById('editar_id').value = habito.dataset.id;
            document.getElementById('editar_nombre').value = habito.dataset.nombre;
            document.getElementById('editar_descripcion').value = habito.dataset.descripcion;
            document.getElementById('editar_frecuencia').value = habito.dataset.frecuencia;
            // Días de la semana
            const dias = habito.dataset.dias ? habito.dataset.dias.split(',') : [];
            document.querySelectorAll('#editar_dias-semana input[type=checkbox]').forEach(cb => {
                cb.checked = dias.includes(cb.value);
            });
            document.getElementById('editar_dias-semana').style.display = habito.dataset.frecuencia === 'semanal' ? 'block' : 'none';
            document.getElementById('modalEditarHabito').style.display = 'flex';
        }
        function cerrarModalEditar() {
            document.getElementById('modalEditarHabito').style.display = 'none';
        }
        document.querySelectorAll('.btn-editar-habito').forEach(btn => {
            btn.addEventListener('click', function() {
                abrirModalEditar(this.closest('.habito-card'));
            });
        });
        document.getElementById('editar_frecuencia').addEventListener('change', function() {
            document.getElementById('editar_dias-semana').style.display = this.value === 'semanal' ? 'block' : 'none';
        });
        document.getElementById('formEditarHabito').addEventListener('submit', async function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            const response = await fetch('editar_habito.php', { method: 'POST', body: formData });
            const res = await response.json();
            if (res.success) {
                location.reload();
            } else {
                alert(res.error || 'Error al guardar los cambios');
            }
        });
        document.querySelectorAll('.btn-eliminar-habito').forEach(btn => {
            btn.addEventListener('click', async function() {
                if (confirm('¿Seguro que deseas eliminar este hábito?')) {
                    const id = this.closest('.habito-card').dataset.id;
                    const formData = new FormData();
                    formData.append('id', id);
                    const response = await fetch('eliminar_habito.php', { method: 'POST', body: formData });
                    const res = await response.json();
                    if (res.success) {
                        location.reload();
                    } else {
                        alert(res.error || 'Error al eliminar el hábito');
                    }
                }
            });
        });

        function mostrarInsigniaModal(src, texto) {
            document.getElementById('imgModalInsignia').src = src;
            document.getElementById('textoModalInsignia').textContent = texto;
            document.getElementById('modalInsignia').style.display = 'flex';
        }
        document.getElementById('cerrarModalInsignia').onclick = function() {
            document.getElementById('modalInsignia').style.display = 'none';
        }
        document.getElementById('modalInsignia').onclick = function(e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        }

        // --- Gráficas de avance de hábitos ---
        async function cargarGraficasAvanceHabitos() {
            try {
                const response = await fetch('obtener_avance_habitos.php');
                const datos = await response.json();
                if (datos.error) {
                    console.error('Error:', datos.error);
                    return;
                }
                const labels = datos.map(h => h.nombre);
                const avanceSemanal = datos.map(h => h.porcentaje_semana);
                const avanceTotal = datos.map(h => h.porcentaje_total);

                // Gráfica semanal
                const ctxSemanal = document.getElementById('graficoAvanceSemanal').getContext('2d');
                new Chart(ctxSemanal, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: '% completado esta semana',
                            data: avanceSemanal,
                            backgroundColor: '#2563eb',
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: { display: false } },
                        scales: {
                            y: { beginAtZero: true, max: 100, ticks: { stepSize: 10, callback: v => v + '%' } }
                        }
                    }
                });
                // Gráfica total
                const ctxTotal = document.getElementById('graficoAvanceTotal').getContext('2d');
                new Chart(ctxTotal, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: '% completado desde creación',
                            data: avanceTotal,
                            backgroundColor: '#43b97f',
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: { display: false } },
                        scales: {
                            y: { beginAtZero: true, max: 100, ticks: { stepSize: 10, callback: v => v + '%' } }
                        }
                    }
                });
            } catch (error) {
                console.error('Error al cargar gráficas de avance:', error);
            }
        }
        // Llamar a la función al cargar la sección de progreso
        if (document.getElementById('graficoAvanceSemanal')) {
            cargarGraficasAvanceHabitos();
        }
    </script>
</body>
</html> 