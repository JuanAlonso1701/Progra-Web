<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../ingresar.php");
    exit();
}

// Incluir archivo de conexión
require_once '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = filter_var($_POST['nombre'], FILTER_SANITIZE_STRING);
    $descripcion = filter_var($_POST['descripcion'], FILTER_SANITIZE_STRING);
    $frecuencia = $_POST['frecuencia'];
    $dias_semana = isset($_POST['dias']) ? implode(',', $_POST['dias']) : null;

    if (empty($nombre)) {
        $_SESSION['error'] = "El nombre del hábito es requerido";
        header("Location: index.php");
        exit();
    }

    try {
        $stmt = $conn->prepare("INSERT INTO habitos (usuario_id, nombre, descripcion, frecuencia, dias_semana) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$_SESSION['usuario_id'], $nombre, $descripcion, $frecuencia, $dias_semana]);
        
        $_SESSION['mensaje'] = "Hábito agregado exitosamente";
    } catch(PDOException $e) {
        $_SESSION['error'] = "Error al agregar el hábito: " . $e->getMessage();
    }

    header("Location: index.php");
    exit();
} else {
    header("Location: index.php");
    exit();
}
?> 