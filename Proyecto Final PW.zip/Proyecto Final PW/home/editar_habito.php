<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No autorizado']);
    exit();
}

// Incluir archivo de conexión
require_once '../conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT);
    $nombre = strip_tags($_POST['nombre']);
    $descripcion = strip_tags($_POST['descripcion']);
    $frecuencia = $_POST['frecuencia'];
    $dias_semana = isset($_POST['dias']) ? implode(',', $_POST['dias']) : null;

    try {
        // Verificar que el hábito pertenece al usuario
        $stmt = $conn->prepare("SELECT id FROM habitos WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$id, $_SESSION['usuario_id']]);
        if ($stmt->rowCount() === 0) {
            echo json_encode(['error' => 'No autorizado o hábito no encontrado']);
            exit();
        }

        // Actualizar el hábito
        $stmt = $conn->prepare("UPDATE habitos SET nombre = ?, descripcion = ?, frecuencia = ?, dias_semana = ? WHERE id = ?");
        $stmt->execute([$nombre, $descripcion, $frecuencia, $dias_semana, $id]);
        
        echo json_encode(['success' => true]);
    } catch(PDOException $e) {
        echo json_encode(['error' => 'Error al actualizar el hábito: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Método no permitido']);
}
?> 