<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No autorizado']);
    exit();
}

require_once '../conexion.php';

try {
    // Obtener todos los hábitos del usuario
    $stmt = $conn->prepare("SELECT id, nombre, frecuencia, fecha_creacion, dias_semana FROM habitos WHERE usuario_id = ?");
    $stmt->execute([$_SESSION['usuario_id']]);
    $habitos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $resultados = [];
    $hoy = new DateTime();
    $inicioSemana = clone $hoy;
    $inicioSemana->modify('monday this week');
    $finSemana = clone $inicioSemana;
    $finSemana->modify('+6 days');

    foreach ($habitos as $habito) {
        $id = $habito['id'];
        $nombre = $habito['nombre'];
        $frecuencia = $habito['frecuencia'];
        $fecha_creacion = new DateTime($habito['fecha_creacion']);
        $dias_semana = $habito['dias_semana'];

        // --- Progreso total ---
        // Calcular días posibles desde la creación
        $dias_posibles = 0;
        $dias_completados = 0;
        $fecha_inicio = clone $fecha_creacion;
        $fecha_fin = clone $hoy;
        $interval = new DateInterval('P1D');
        $periodo = new DatePeriod($fecha_inicio, $interval, $fecha_fin->modify('+1 day'));
        if ($frecuencia == 'diario') {
            $dias_posibles = iterator_count($periodo);
        } else if ($frecuencia == 'semanal' && $dias_semana) {
            $dias_array = explode(',', $dias_semana);
            foreach ($periodo as $fecha) {
                if (in_array($fecha->format('w'), $dias_array)) {
                    $dias_posibles++;
                }
            }
        }
        // Completados totales
        $stmt2 = $conn->prepare("SELECT COUNT(*) FROM seguimiento_habitos WHERE habito_id = ? AND completado = 1");
        $stmt2->execute([$id]);
        $dias_completados = (int)$stmt2->fetchColumn();
        $porcentaje_total = $dias_posibles > 0 ? round(($dias_completados / $dias_posibles) * 100, 1) : 0;

        // --- Progreso semanal ---
        $dias_posibles_semana = 0;
        $dias_completados_semana = 0;
        $periodo_semana = new DatePeriod($inicioSemana, $interval, $finSemana->modify('+1 day'));
        if ($frecuencia == 'diario') {
            $dias_posibles_semana = 7;
        } else if ($frecuencia == 'semanal' && $dias_semana) {
            $dias_array = explode(',', $dias_semana);
            foreach ($periodo_semana as $fecha) {
                if (in_array($fecha->format('w'), $dias_array)) {
                    $dias_posibles_semana++;
                }
            }
        }
        $stmt3 = $conn->prepare("SELECT COUNT(*) FROM seguimiento_habitos WHERE habito_id = ? AND completado = 1 AND fecha >= ? AND fecha <= ?");
        $stmt3->execute([$id, $inicioSemana->format('Y-m-d'), $finSemana->format('Y-m-d')]);
        $dias_completados_semana = (int)$stmt3->fetchColumn();
        $porcentaje_semana = $dias_posibles_semana > 0 ? round(($dias_completados_semana / $dias_posibles_semana) * 100, 1) : 0;

        $resultados[] = [
            'nombre' => $nombre,
            'porcentaje_total' => $porcentaje_total,
            'porcentaje_semana' => $porcentaje_semana
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($resultados);
} catch(PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
} 