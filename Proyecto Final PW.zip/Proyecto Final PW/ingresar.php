<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ingresar - Avanza</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Encabezado -->
    <header class="encabezado">
        <div class="contenedor">
            <h1 class="logo">Avanza</h1>
            <nav class="navegacion">
                <a href="index.html" class="boton-secundario">Inicio</a>
                <a href="registro.php" class="boton-principal">Registrarse</a>
            </nav>
        </div>
    </header>

    <!-- Formulario de Ingreso -->
    <section class="formulario-registro">
        <h2>Ingresa a tu cuenta</h2>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="error" style="color: #fff; background: #e74c3c; padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
        <form action="procesar_login.php" method="POST">
            <div class="campo-formulario">
                <label for="email">Correo electrónico:</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="campo-formulario">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="boton-registro">Ingresar</button>

            <div class="opciones-formulario">
                <a href="restablecer_password.php" class="enlace-login">¿Olvidaste tu contraseña?</a>
            </div>
            
        </form>
    </section>

    <!-- Pie de página -->
    <footer class="pie">
        <div class="contenedor">
            <p>Contacto: <a href="mailto:contactoavanza@gmail.com">contactoavanza@gmail.com</a></p>
            <p>© 2025 Avanza. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html> 