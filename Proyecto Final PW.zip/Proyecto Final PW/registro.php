<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registro - Avanza</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Encabezado -->
    <header class="encabezado">
        <div class="contenedor">
            <h1 class="logo">Avanza</h1>
            <nav class="navegacion">
                <a href="index.html" class="boton-principal">Inicio</a>
            </nav>
        </div>
    </header>

    <!-- Formulario de Registro -->
    <main class="formulario-registro">
        <h2>Crear una cuenta</h2>
        <form action="procesar_registro.php" method="POST">
            <div class="campo-formulario">
                <label for="nombre">Nombre completo</label>
                <input type="text" id="nombre" name="nombre" required>
            </div>
            
            <div class="campo-formulario">
                <label for="email">Correo electrónico</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="campo-formulario">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <div class="campo-formulario">
                <label for="confirmar_password">Confirmar contraseña</label>
                <input type="password" id="confirmar_password" name="confirmar_password" required>
            </div>
            
            <button type="submit" class="boton-registro">Registrarse</button>
        </form>
        
        <div class="enlace-login">
            <p>¿Ya tienes una cuenta? <a href="ingresar.php">Inicia sesión</a></p>
        </div>
    </main>

    <!-- Pie de página -->
    <footer class="pie">
        <div class="contenedor">
            <p>Contacto: <a href="mailto:contactoavanza@gmail.com">contactoavanza@gmail.com</a></p>
            <p>© 2025 Avanza. Todos los derechos reservados.</p>
        </div>
    </footer>
</body>
</html> 