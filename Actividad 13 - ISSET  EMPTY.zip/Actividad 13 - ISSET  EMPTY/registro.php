<?php
// Variables para almacenar los datos y los mensajes de error
$nombre = "";
$edad = "";
$email = "";
$error = "";
$resultado = "";

// Verifica si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica si las variables existen antes de asignarlas
    if (isset($_POST["nombre"])) {
        $nombre = $_POST["nombre"];
    }
    if (isset($_POST["edad"])) {
        $edad = $_POST["edad"];
    }
    if (isset($_POST["email"])) {
        $email = $_POST["email"];
    }

    // Verifica si algun campo esta vacio
    if (empty($nombre) || empty($edad) || empty($email)) {
        $error = "Todos los campos son obligatorios.";
    } else {
        $resultado = "<p><strong>Registro:</strong></p><p>Nombre: 
        $nombre</p><p>Edad: 
        $edad</p><p>Email: 
        $email</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Actividad 14 - ISSET / EMPTY</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <a href="/./index.html">Inicio</a>
    <div class="container">
        <!-- Formulario -->
        <form method="post">
            <label>Nombre:</label>
            <input type="text" name="nombre" value="<?php echo $nombre; ?>" required>
            <br>
            <label>Edad:</label>
            <input type="text" name="edad" value="<?php echo $edad; ?>" required>
            <br>
            <label>Email:</label>
            <input type="text" name="email" value="<?php echo $email; ?>" required>
            <br>
            <input type="submit" value="Enviar">
            <p class="error"><?php echo $error; ?></p>
        </form>
        
        <!-- Muestra los datos ingresados -->
        <?php if ($resultado): ?>
            <div class="resultado">
                <?php echo $resultado; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>